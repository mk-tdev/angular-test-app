import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Todo } from '../models/todo';

@Injectable({
  providedIn: 'root',
})
export class TodosService {
  private todosSubject: BehaviorSubject<Todo[]> = new BehaviorSubject<Todo[]>(
    []
  );
  private todos$: Observable<Todo[]> = this.todosSubject.asObservable();

  constructor() {
    this.todosSubject.next([
      { id: '1', todoTitle: 'Learn Angular', completed: true },
      { id: '2', todoTitle: 'Learn NGRX', completed: false },
    ]);
  }

  getTodos(): Observable<Todo[]> {
    return this.todos$;
  }

  addTodo(todoTitle: string): void {
    const todos = this.todosSubject.getValue();

    const newTodo: Todo = {
      id: Date.now().toString(),
      todoTitle,
      completed: false,
    };

    this.todosSubject.next([...todos, newTodo]);
  }

  toggleTodo(id: string): void {
    const todos = this.todosSubject.getValue();
    const updatedTodos = todos.map((todo) =>
      todo.id === id ? { ...todo, completed: !todo.completed } : todo
    );
    this.todosSubject.next(updatedTodos);
  }

  deleteTodo(id: string): void {
    const todos = this.todosSubject.getValue();
    const updatedTodos = todos.filter((todo) => todo.id !== id);
    this.todosSubject.next(updatedTodos);
  }
}
