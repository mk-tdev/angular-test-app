export type Todo = {
  todoTitle: string;
  id: string;
  completed: boolean;
};
