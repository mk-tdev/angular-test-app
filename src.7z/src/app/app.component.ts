import { Component } from '@angular/core';
import { HeadersComponent } from './components/headers/headers.component';
import { TodoListComponent } from './components/todo-list/todo-list.component';
import { AddTodoItemComponent } from "./components/add-todo-item/add-todo-item.component";

@Component({
  selector: 'app-root',
  imports: [HeadersComponent, TodoListComponent, AddTodoItemComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'test-routing';
}
