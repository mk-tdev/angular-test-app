import { Component } from '@angular/core';
import { AddTodoItemComponent } from '../add-todo-item/add-todo-item.component';
import { TodoItemComponent } from '../todo-item/todo-item.component';
import { TodosService } from '../../services/todos.service';
import { Observable, of } from 'rxjs';
import { Todo } from '../../models/todo';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-todo-list',
  imports: [CommonModule, AddTodoItemComponent, TodoItemComponent],
  templateUrl: './todo-list.component.html',
  styleUrl: './todo-list.component.scss',
})
export class TodoListComponent {
  todos$: Observable<Todo[]> = of([]);
  completedTodos!: number;
  totalTodos!: number;

  constructor(private todoService: TodosService) {}

  ngOnInit(): void {
    this.todos$ = this.todoService.getTodos();
    this.todos$.subscribe(d => {
      this.totalTodos = d.length;
      this.completedTodos = d.filter(todo => todo.completed).length;
    })
  }

  addTodo(title: string): void {
    this.todoService.addTodo(title);
  }

  handleToggleTodo(id: string): void {
    this.todoService.toggleTodo(id);
  }

  handleDeleteTodo(id: string): void {
    this.todoService.deleteTodo(id);
  }
}
