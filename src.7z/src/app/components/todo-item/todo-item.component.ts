import { CommonModule } from '@angular/common';
import {
  Component,
  EventEmitter,
  HostBinding,
  Input,
  Output,
  ViewEncapsulation,
} from '@angular/core';
import { Todo } from '../../models/todo';

@Component({
  selector: 'app-todo-item',
  imports: [CommonModule],
  templateUrl: './todo-item.component.html',
  styleUrl: './todo-item.component.scss',
  encapsulation: ViewEncapsulation.None,
})
export class TodoItemComponent {
  @Input() todo!: Todo;
  @Output() toggleTodo = new EventEmitter<string>();
  @Output() deleteTodo = new EventEmitter<string>();

  @HostBinding('class.completed') get completed() {
    return this.todo.completed;
  }

  onToggle(): void {
    this.toggleTodo.emit(this.todo.id);
  }

  onDelete(): void {
    this.deleteTodo.emit(this.todo.id);
  }
}
