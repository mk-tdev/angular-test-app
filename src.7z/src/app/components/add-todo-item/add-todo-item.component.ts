import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-add-todo-item',
  imports: [FormsModule, CommonModule],
  templateUrl: './add-todo-item.component.html',
  styleUrl: './add-todo-item.component.scss',
})
export class AddTodoItemComponent {
  todoTitle: string = '';
  @Output() addTodo = new EventEmitter<string>();

  handleAdd() {
    if(this.todoTitle.trim()) {
      this.addTodo.emit(this.todoTitle);
      this.todoTitle = '';
    }
  }
}
