import { Component } from '@angular/core';
import { TodosService } from '../../services/todos.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-headers',
  imports: [],
  templateUrl: './headers.component.html',
  styleUrl: './headers.component.scss',
})
export class HeadersComponent {
  private subs = new Subscription();
  todoListCount: number = 0;

  constructor(private todoService: TodosService) {}

  ngOnInit(): void {
    const todoSub = this.todoService.getTodos().subscribe((data) => {
      this.todoListCount = data.length;
    });

    this.subs.add(todoSub);
  }

  ngOnDestroy(): void {
    this.subs.unsubscribe();
  }
}
